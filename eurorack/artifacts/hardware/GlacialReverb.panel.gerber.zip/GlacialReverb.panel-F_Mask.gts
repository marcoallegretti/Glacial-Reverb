%TF.GenerationSoftware,KiCad,Pcbnew,(6.0.11)*%
%TF.CreationDate,2026-07-14T19:49:54+02:00*%
%TF.ProjectId,GlacialReverb.panel,476c6163-6961-46c5-9265-766572622e70,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW (6.0.11)) date 2026-07-14 19:49:54*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10O,7.800000X4.600000*%
G04 APERTURE END LIST*
D10*
%TO.C,*%
X7500000Y-125500000D03*
%TD*%
%TO.C,*%
X53220000Y-3000000D03*
%TD*%
%TO.C,*%
X53220000Y-125500000D03*
%TD*%
%TO.C,*%
X7500000Y-3000000D03*
%TD*%
M02*
